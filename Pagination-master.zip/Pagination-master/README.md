PHP Paginator
=============

A tool to generate reports using pagination
